<?php

return [
    '{attribute} cannot be blank.' => '{attribute} non può essere lasciato in bianco.',
    'The verification code is incorrect.' => 'Il codice di verifica è sbagliato.',
    'Home' => 'Inizio',
    'You are not allowed to perform this action.' => 'Non sei autorizzato a compiere questa azione.'
];
