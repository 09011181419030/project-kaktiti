<?php

return [
    '{attribute} cannot be blank.' => 'поле {attribute} не может быть пустым.',
    'The verification code is incorrect.' => 'Неправильный код подтверждаения.',
    'Home' => 'Главная',
    'You are not allowed to perform this action.' => 'Недостаточно прав для выполнения действия.'
];