<?php

return [
    '{attribute} cannot be blank.' => '{attribute} no puede estar vacío.',
    'The verification code is incorrect.' => 'El código de verificación es incorrecto.',
    'Home' => 'Inicio',
    'You are not allowed to perform this action.' => 'No estás autorizado a hacer esto.'
];
