<?php
namespace tests\codeception\frontend\_pages;

use yii\codeception\BasePage;

/**
 * Represents About Page
 */
class AboutPage extends BasePage
{
    public $route = 'site/about';
}
